# Getting Started

```{include} ../../../README.md
:start-after: <!-- start getting started -->
:end-before: <!-- end getting started -->
```

