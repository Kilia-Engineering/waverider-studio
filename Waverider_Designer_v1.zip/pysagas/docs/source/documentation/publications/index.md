# Publications of PySAGAS

```{toctree}
:maxdepth: 2

2024 <2024>
```
