
# Implementing a New Senstivity Calculater

PySAGAS sensitivity calculators for different CFD solvers all inherit 
from the {py:class}`.SensitivityCalculator` class.
