# Cart3D ShapeOpt Wrapper


```{eval-rst}
.. autoclass:: pysagas.optimisation.cart3d.utilities.C3DPrep
   :members:
```

