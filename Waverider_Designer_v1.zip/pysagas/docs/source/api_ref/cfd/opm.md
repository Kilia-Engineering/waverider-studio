# Oblique / Prandtl-Meyer Flow Solver


```{eval-rst}
.. automodule:: pysagas.cfd.oblique_prandtl_meyer
   :members:
   :private-members:
```
